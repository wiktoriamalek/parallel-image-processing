#include "image_processor.h"
#include <algorithm>
#include <cmath>


void ImageProcessor::setImage(const QImage &img) {
    image = img.convertToFormat(QImage::Format_RGB32);
}

const QImage &ImageProcessor::getImage() const {
    return image;
}

QImage ImageProcessor::applyFilter(const ImageFilter *filter) const {
    return filter->apply(image);
}