#ifndef CONVOLUTIONFILTER_H
#define CONVOLUTIONFILTER_H

#include "image_filter.h"
#include <vector>

class ConvolutionFilter final : public ImageFilter {
public:
    explicit ConvolutionFilter(std::string name, const std::vector<std::vector<f32>> &kernel, f32 divisor = 1.0f, f32 offset = 0.0f);

    [[nodiscard]] QImage apply(const QImage &input) const override;

    std::vector<std::vector<f32>> getKernel() const;

    f32 getDivisor() const;

    f32 getOffset() const;

    [[nodiscard]] std::string getName() const override;
private:
    std::vector<std::vector<f32>> kernel;
    f32 divisor;
    f32 offset;

    std::string name;
};

#endif