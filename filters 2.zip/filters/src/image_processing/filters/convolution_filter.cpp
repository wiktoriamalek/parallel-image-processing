#include "convolution_filter.h"
#include <algorithm>

ConvolutionFilter::ConvolutionFilter(const std::string name, const std::vector<std::vector<f32> > &kernel,
                                     const f32 divisor, const f32 offset)
    : kernel(kernel), divisor(divisor), offset(offset), name(name) {
}

QImage ConvolutionFilter::apply(const QImage &input) const {
    QImage output(input.size(), input.format());
    const i32 kw = static_cast<i32>(kernel[0].size());
    const i32 kh = static_cast<i32>(kernel.size());
    const i32 halfKW = kw / 2;
    const i32 halfKH = kh / 2;

    for (i32 y = 0; y < input.height(); y++) {
        for (i32 x = 0; x < input.width(); x++) {
            f32 sumR = 0, sumG = 0, sumB = 0;
            for (i32 j = 0; j < kh; j++) {
                for (i32 i = 0; i < kw; i++) {
                    i32 curX = x + i - halfKW;
                    i32 curY = y + j - halfKH;
                    curX = std::clamp(curX, 0, input.width() - 1);
                    curY = std::clamp(curY, 0, input.height() - 1);
                    QColor pixel = input.pixelColor(curX, curY);
                    sumR += static_cast<f32>(pixel.red()) * kernel[j][i];
                    sumG += static_cast<f32>(pixel.green()) * kernel[j][i];
                    sumB += static_cast<f32>(pixel.blue()) * kernel[j][i];
                }
            }
            const i32 finalR = std::clamp(static_cast<i32>(sumR / divisor + offset), 0, 255);
            const i32 finalG = std::clamp(static_cast<i32>(sumG / divisor + offset), 0, 255);
            const i32 finalB = std::clamp(static_cast<i32>(sumB / divisor + offset), 0, 255);
            output.setPixelColor(x, y, QColor(finalR, finalG, finalB));
        }
    }
    return output;
}


std::vector<std::vector<f32>> ConvolutionFilter::getKernel() const {
    return kernel;
};

f32 ConvolutionFilter::getDivisor() const {
    return divisor;
};

f32 ConvolutionFilter::getOffset() const {
    return offset;
}

std::string ConvolutionFilter::getName() const {
    return name;
}
