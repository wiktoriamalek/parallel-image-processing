#include "average_dithering_filter.h"
#include <QImage>
#include <QColor>
#include <numeric>

AverageDitheringFilter::AverageDitheringFilter(int greyLevels) {
    this->greyLevels = greyLevels;
}

QImage AverageDitheringFilter::apply(const QImage &input) const {
    QImage img = input.convertToFormat(QImage::Format_RGB32);
    int width = img.width();
    int height = img.height();

    QImage output(width, height, QImage::Format_RGB32);

    float step = 255.0f / (greyLevels - 1);

    for (int y = 0; y < height; y++) {
        QRgb *outScanLine = reinterpret_cast<QRgb*>(output.scanLine(y));
        for (int x = 0; x < width; x++) {
            QColor color = img.pixelColor(x, y);
            int brightness = (color.red() + color.green() + color.blue()) / 3;
            int quant = static_cast<int>(std::round(brightness / step) * step);
            quant = std::clamp(quant, 0, 255);
            outScanLine[x] = qRgb(quant, quant, quant);
        }
    }
    return output;
}


std::string AverageDitheringFilter::getName() const {
    return "Average Dithering";
}