#ifndef MEDIAN_CUT_QUANTIZATION_EDITOR_H
#define MEDIAN_CUT_QUANTIZATION_EDITOR_H

#include <QWidget>
#include <memory>
#include <string>


class ImageFilter;
class QLineEdit;
class QPushButton;
class QSpinBox;

class MedianCutQuantizationFilterEditor final : public QWidget {
    Q_OBJECT

    int desiredColors = 0;


public:
    explicit MedianCutQuantizationFilterEditor(QWidget *parent = nullptr);
    void loadFilter(int desiredColors, std::string name);

signals:
    void filterSaved(std::shared_ptr<ImageFilter> filter);

private slots:
    void onSaveClicked();

private:
    QLineEdit *nameEdit;
    QSpinBox *colorCountSpin;
    QPushButton *saveButton;
};

#endif
