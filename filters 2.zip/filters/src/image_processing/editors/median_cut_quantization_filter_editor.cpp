#include "median_cut_quantization_filter_editor.h"
#include "../filters/median_cut_quantization_filter.h"
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSpinBox>

MedianCutQuantizationFilterEditor::MedianCutQuantizationFilterEditor(QWidget *parent)
    : QWidget(parent)
{
    setWindowFlags(Qt::Window);
    setWindowTitle("Median Cut Quantization Editor");

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(10);
    mainLayout->setContentsMargins(10, 10, 10, 10);

    QHBoxLayout *nameLayout = new QHBoxLayout;
    nameLayout->addWidget(new QLabel("Filter Name:", this));
    nameEdit = new QLineEdit(this);
    nameLayout->addWidget(nameEdit);
    mainLayout->addLayout(nameLayout);

    QHBoxLayout *colorsLayout = new QHBoxLayout;
    colorsLayout->addWidget(new QLabel("Number of Colors:", this));
    colorCountSpin = new QSpinBox(this);
    colorCountSpin->setRange(2, 256);
    colorCountSpin->setValue(desiredColors);
    colorsLayout->addWidget(colorCountSpin);
    mainLayout->addLayout(colorsLayout);

    saveButton = new QPushButton("Save", this);
    mainLayout->addWidget(saveButton, 0, Qt::AlignCenter);

    connect(saveButton, &QPushButton::clicked, this, &MedianCutQuantizationFilterEditor::onSaveClicked);

    setLayout(mainLayout);
}


void MedianCutQuantizationFilterEditor::loadFilter(int desiredColors, std::string name) {
    this->desiredColors = desiredColors;
    colorCountSpin->setValue(desiredColors);

    nameEdit->setText(QString::fromStdString(name));
    nameEdit->setDisabled(true);
}



void MedianCutQuantizationFilterEditor::onSaveClicked() {
    std::string filterName = nameEdit->text().toStdString();
    if (filterName.empty()) {
        return;
    }


    int targetColors = colorCountSpin->value();
    auto filter = std::make_shared<MedianCutQuantizationFilter>(targetColors, filterName);

    emit filterSaved(filter);
    close();
}

