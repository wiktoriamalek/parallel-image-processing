#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QComboBox>
#include <QMainWindow>
#include "../image_processing/image_processor.h"

class QLabel;

class MainWindow final : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

    std::shared_ptr<ImageFilter> getFilterByName(std::string name);
    void addFilter(std::shared_ptr<ImageFilter> filter);
    void updateFilter(std::shared_ptr<ImageFilter> newFilter);

private slots:
    void openImage_action();
    void applyFilter_action(const std::shared_ptr<ImageFilter> &filter);
    void saveImage_action();
    void resetImage_action();

private:
    void refreshFiltersCombobox() const;

    void refreshEditMenu();

    void refreshEditMenu() const;

    [[nodiscard]] QPixmap adjustPixmapToFitToBoundary(const QPixmap *pixmap) const;

    QLabel *imageLabel;
    QImage originalImage;
    ImageProcessor processor;

    std::shared_ptr<std::vector<std::shared_ptr<ImageFilter> > > filters;
    QComboBox *filtersComboBox;
    QMenu *editMenu;
};

#endif
