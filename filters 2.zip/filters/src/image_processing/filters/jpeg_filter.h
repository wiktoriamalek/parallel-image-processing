#ifndef JPEG_FILTER_H
#define JPEG_FILTER_H

#include <QImage>
#include <string>

#include "image_filter.h"

class JpegFilter : public ImageFilter {
public:
    virtual ~JpegFilter() = default;
    [[nodiscard]] QImage apply(const QImage &input) const override;
    [[nodiscard]] std::string getName() const override;
};

#endif
