#include "get_built_in_filters.h"

#include "../image_processing/filters/image_filter.h"
#include "../image_processing/filters/functional_filter.h"
#include "../image_processing/filters/convolution_filter.h"

#include <vector>
#include <cmath>

#include "../image_processing/filters/average_dithering_filter.h"
#include "../image_processing/filters/greyscale_filter.h"
#include "../image_processing/filters/jpeg_filter.h"
#include "../image_processing/filters/median_cut_quantization_filter.h"
#include "../image_processing/filters/morphological_filter.h"

std::shared_ptr<std::vector<std::shared_ptr<ImageFilter>>> getBuiltInFilters() {
    auto builtInFilters = std::make_shared<std::vector<std::shared_ptr<ImageFilter> > >();

    std::vector<i32> inversionMapping(256);
    for (i32 i = 0; i < 256; i++) {
        inversionMapping[i] = 255 - i;
    }

    builtInFilters->push_back(std::make_shared<FunctionalFilter>("Inversion", inversionMapping));

    std::vector<i32> brightnessMapping(256);
    for (i32 i = 0; i < 256; i++) {
        brightnessMapping[i] = std::clamp(i + 10, 0, 255);
    }
    builtInFilters->push_back(std::make_shared<FunctionalFilter>("Brightness", brightnessMapping));

    std::vector<i32> contrastMapping(256);
    for (i32 i = 0; i < 256; i++) {
        contrastMapping[i] = std::clamp(static_cast<i32>((i - 127) * 1.2 + 127), 0, 255);
    }
    builtInFilters->push_back(std::make_shared<FunctionalFilter>("Contrast", contrastMapping));

    std::vector<i32> gammaMapping(256);

    for (i32 i = 0; i < 256; i++) {
        constexpr f64 gamma = 0.8;
        gammaMapping[i] = std::clamp(static_cast<i32>(255 * std::pow(i / 255.0, gamma)), 0, 255);
    }
    builtInFilters->push_back(std::make_shared<FunctionalFilter>("Gamma", gammaMapping));

    std::vector<std::vector<f32>> blurKernel = {
        {1, 1, 1},
        {1, 1, 1},
        {1, 1, 1}
    };
    builtInFilters->push_back(std::make_shared<ConvolutionFilter>("Blur", blurKernel, 9.0f, 0.0f));

    std::vector<std::vector<f32>> gaussianKernel = {
        {1, 2, 1},
        {2, 4, 2},
        {1, 2, 1}
    };
    builtInFilters->push_back(std::make_shared<ConvolutionFilter>("Gaussian Blur", gaussianKernel, 16.0f, 0.0f));

    std::vector<std::vector<f32>> sharpenKernel = {
        {  0, -1,  0 },
        { -1,  5, -1 },
        {  0, -1,  0 }
    };
    builtInFilters->push_back(std::make_shared<ConvolutionFilter>("Sharpen", sharpenKernel, 1.0f, 0.0f));

    std::vector<std::vector<f32>> edgeKernel = {
        { -1, -1, -1 },
        { -1,  8, -1 },
        { -1, -1, -1 }
    };
    builtInFilters->push_back(std::make_shared<ConvolutionFilter>("Edge Detection", edgeKernel, 1.0f, 0.0f));

    std::vector<std::vector<f32>> embossKernel = {
        { -2, -1,  0 },
        { -1,  1,  1 },
        {  0,  1,  2 }
    };
    builtInFilters->push_back(std::make_shared<ConvolutionFilter>("Emboss", embossKernel, 1.0f, 128.0f));

    builtInFilters->push_back(std::make_shared<MorphologicalFilter>(MorphologicalOperation::Erosion));
    builtInFilters->push_back(std::make_shared<MorphologicalFilter>(MorphologicalOperation::Dilation));

    builtInFilters->push_back(std::make_shared<AverageDitheringFilter>(5));
    builtInFilters->push_back(std::make_shared<MedianCutQuantizationFilter>(3));
    builtInFilters->push_back(std::make_shared<GreyscaleFilter>());
    builtInFilters->push_back(std::make_shared<JpegFilter>());

    return builtInFilters;
}
