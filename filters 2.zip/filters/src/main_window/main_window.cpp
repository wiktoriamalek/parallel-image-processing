#include "main_window.h"

#include <QFileDialog>
#include <QLabel>
#include <QToolBar>
#include <QMessageBox>
#include <QComboBox>
#include <QMenu>
#include <QToolButton>
#include <__ranges/filter_view.h>

#include "get_built_in_filters.h"
#include "../image_processing/editors/convolution_filter_editor.h"
#include "../image_processing/editors/functional_filter_editor.h"
#include "../image_processing/editors/median_cut_quantization_filter_editor.h"
#include "../image_processing/filters/convolution_filter.h"
#include "../image_processing/filters/functional_filter.h"
#include "../image_processing/filters/median_cut_quantization_filter.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    setWindowTitle("Image Filtering");
    setWindowFlags(windowFlags() & ~Qt::WindowFullscreenButtonHint);
    setWindowFlags(windowFlags() & ~Qt::WindowMaximizeButtonHint);


    QToolBar *toolbar = addToolBar("Main Toolbar");

    const QAction *loadAction = toolbar->addAction("Load Image");
    connect(loadAction, &QAction::triggered, this, &MainWindow::openImage_action);

    const QAction *saveAction = toolbar->addAction("Save Image");
    connect(saveAction, &QAction::triggered, this, &MainWindow::saveImage_action);

    const QAction *resetAction = toolbar->addAction("Reset");
    connect(resetAction, &QAction::triggered, this, &MainWindow::resetImage_action);

    filtersComboBox = new QComboBox(this);
    filters = getBuiltInFilters();
    refreshFiltersCombobox();

    imageLabel = new QLabel(this);
    imageLabel->setAlignment(Qt::AlignCenter);
    setCentralWidget(imageLabel);

    const QAction *applyAction = toolbar->addAction("Apply Filter");
    connect(applyAction, &QAction::triggered, this, [this] {
        i32 currentIndex = this->filtersComboBox->currentIndex();
        if (currentIndex == 0) {
            QMessageBox::information(this, tr("Error"), tr("No filter was selected."));
            return;
        }
        applyFilter_action(this->filters->at(currentIndex - 1));
    });

    toolbar->addWidget(filtersComboBox);

    editMenu = new QMenu("Edit", this);
    refreshEditMenu();


    auto *spacer = new QWidget(this);
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    toolbar->addWidget(spacer);

    auto editButton = new QToolButton(this);

    editButton->setText("Edit filters");
    editButton->setMenu(editMenu);
    editButton->setPopupMode(QToolButton::InstantPopup);
    toolbar->addWidget(editButton);
}

std::shared_ptr<ImageFilter> MainWindow::getFilterByName(std::string name) {
    return nullptr;
}

void MainWindow::addFilter(std::shared_ptr<ImageFilter> filter) {
    filters->push_back(filter);
    refreshEditMenu();
    refreshFiltersCombobox();
}

void MainWindow::updateFilter(std::shared_ptr<ImageFilter> newFilter) {
    for (i32 i = 0; i < filters->size(); i++) {
        if (filters->at(i)->getName() == newFilter->getName()) {
            filters->at(i) = newFilter;
            refreshEditMenu();
            refreshFiltersCombobox();
            return;
        }
    }
}


void MainWindow::openImage_action() {
    if (const QString fileName = QFileDialog::getOpenFileName(this, tr("Open Image"), "",
                                                              tr("Images (*.png *.jpg *.bmp)")); !fileName.isEmpty()) {
        const QImage loadedImage(fileName);
        if (loadedImage.isNull()) {
            QMessageBox::information(this, tr("Error"), tr("The image could not be loaded."));
            return;
        }
        originalImage = loadedImage;
        processor.setImage(originalImage);

        const QPixmap pixmap = QPixmap::fromImage(loadedImage);
        imageLabel->setPixmap(pixmap);
    }
}

void MainWindow::applyFilter_action(const std::shared_ptr<ImageFilter> &filter) {
    if (processor.getImage().isNull()) {
        QMessageBox::information(this, tr("Error"), tr("No image was loaded."));
        return;
    }

    const QImage filteredImage = processor.applyFilter(filter.get());

    const QPixmap pixmap = QPixmap::fromImage(filteredImage);
    imageLabel->setPixmap(pixmap);
    processor.setImage(filteredImage);
}

void MainWindow::saveImage_action() {
    if (processor.getImage().isNull()) {
        QMessageBox::information(this, tr("Error"), tr("No image was loaded."));
        return;
    }
    if (const QString fileName = QFileDialog::getSaveFileName(this, tr("Save Image"), "",
                                                              tr("Images (*.png *.jpg *.bmp)")); !fileName.isEmpty()) {
        if (const QImage finalImage = processor.getImage(); !finalImage.save(fileName)) {
            QMessageBox::information(this, tr("Error"), tr("The image could not be saved."));
        }
    }
}

void MainWindow::resetImage_action() {
    if (processor.getImage().isNull()) {
        QMessageBox::information(this, tr("Error"), tr("No image was loaded."));
        return;
    }

    processor.setImage(originalImage);

    const QPixmap pixmap = QPixmap::fromImage(originalImage);
    imageLabel->setPixmap(pixmap);
}

void MainWindow::refreshFiltersCombobox() const {
    filtersComboBox->clear();

    filtersComboBox->addItem("Select filter...");
    filtersComboBox->setItemData(0, QVariant(0), Qt::UserRole - 1);

    for (i32 i = 0; i < filters->size(); ++i) {
        filtersComboBox->addItem(filters->at(i)->getName().data());
    }
}

void MainWindow::refreshEditMenu() {
    editMenu->clear();

    for (i32 i = 0; i < filters->size(); ++i) {
        QAction *editFilterAction = editMenu->addAction(filters->at(i)->getName().c_str());
        connect(editFilterAction, &QAction::triggered, this, [this, i]() {
            ImageFilter *filter = filters->at(i).get();

            if (auto funcFilter = dynamic_cast<FunctionalFilter *>(filter)) {
                FunctionalFilterEditor *editor = new FunctionalFilterEditor(this);
                connect(editor, &FunctionalFilterEditor::filterSaved, this, &MainWindow::updateFilter);

                editor->loadFilter(funcFilter->getName(), funcFilter->getTenControlPoints());
                editor->setAttribute(Qt::WA_DeleteOnClose);
                editor->show();
            } else if (auto convFilter = dynamic_cast<ConvolutionFilter *>(filter)) {
                ConvolutionFilterEditor *editor = new ConvolutionFilterEditor(this);
                connect(editor, &ConvolutionFilterEditor::filterSaved, this, &MainWindow::updateFilter);
                editor->loadFilter(convFilter->getName(), convFilter->getKernel(), convFilter->getDivisor(),
                                   convFilter->getOffset());
                editor->setAttribute(Qt::WA_DeleteOnClose);
                editor->show();
            } else if (auto medianCutQuantizationFilter = dynamic_cast<MedianCutQuantizationFilter *>(filter)) {
                MedianCutQuantizationFilterEditor *editor = new MedianCutQuantizationFilterEditor(this);
                connect(editor, &MedianCutQuantizationFilterEditor::filterSaved, this, &MainWindow::updateFilter);
                editor->loadFilter(medianCutQuantizationFilter->getDesiredColors(), medianCutQuantizationFilter->getName());
                editor->setAttribute(Qt::WA_DeleteOnClose);
                editor->show();
            }
        });
    }

    editMenu->addAction("");
    QMenu *newFilterMenu = editMenu->addMenu("New Filter");

    QAction *newFunctionalAction = newFilterMenu->addAction("Functional");
    connect(newFunctionalAction, &QAction::triggered, this, [this] {
        auto *editor = new FunctionalFilterEditor(this);
        connect(editor, &FunctionalFilterEditor::filterSaved, this, &MainWindow::addFilter);

        editor->setAttribute(Qt::WA_DeleteOnClose);
        editor->setWindowTitle("New Functional Filter");
        editor->show();
    });

    QAction *newConvolutionAction = newFilterMenu->addAction("Convolution");
    connect(newConvolutionAction, &QAction::triggered, this, [this] {
        auto *editor = new ConvolutionFilterEditor(this);
        connect(editor, &ConvolutionFilterEditor::filterSaved, this, &MainWindow::addFilter);

        editor->setAttribute(Qt::WA_DeleteOnClose);
        editor->setWindowTitle("New Convolution Filter");
        editor->show();
    });
}

QPixmap MainWindow::adjustPixmapToFitToBoundary(const QPixmap *pixmap) const {
    return pixmap->scaled(imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
}
