#include "jpeg_filter.h"

#include <QImage>

#include "average_dithering_filter.h"


QImage JpegFilter::apply(const QImage &input) const {
    QImage output = input.convertToFormat(QImage::Format_RGB32);
    int width = output.width();
    int height = output.height();
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QColor color = output.pixelColor(x, y);
            const auto luminance = 0.299 * color.red() + 0.587 * color.green() + 0.114 * color.blue();
            const auto cb = 128 - 0.168736 * color.red() - 0.331264 * color.green() + 0.5 * color.blue();
            const auto cr = 128 + 0.5 * color.red() - 0.418688 * color.green() - 0.081312 * color.blue();

            QColor ycbcrColor(luminance, cb, cr);
            output.setPixelColor(x, y, ycbcrColor);
        }
    }

    const AverageDitheringFilter ditheringFilter(5);
    auto output2 = ditheringFilter.apply(output);

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QColor color = output2.pixelColor(x, y);
            const auto r = color.red() + 1.402 * (color.green() - 128);
            const auto g = color.red() - 0.344136 * (color.green() - 128) - 0.71436 * (color.blue() - 128);
            const auto b = color.red() + 1.772 * (color.green() - 128);

            QColor rgbColor(r, g, b);
            output2.setPixelColor(x, y, rgbColor);
        }
    }

    return output2;
}


std::string JpegFilter::getName() const {
    return "YCbCr Filter";
}

