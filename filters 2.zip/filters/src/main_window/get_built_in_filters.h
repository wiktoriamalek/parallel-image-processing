#ifndef DEFAULT_FILTERS_H
#define DEFAULT_FILTERS_H


#include <vector>

class ImageFilter;

std::shared_ptr<std::vector<std::shared_ptr<ImageFilter>>> getBuiltInFilters();

#endif
