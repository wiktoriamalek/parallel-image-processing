#include "convolution_filter_editor.h"
#include "../filters/convolution_filter.h"
#include <QHBoxLayout>
#include <QLabel>
#include <QTableWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QHeaderView>

ConvolutionFilterEditor::ConvolutionFilterEditor(QWidget *parent)
    : QWidget(parent) {
    setWindowTitle("Convolution Filter Editor");
    setWindowFlags(Qt::Window);
    setAttribute(Qt::WA_DeleteOnClose);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);

        QHBoxLayout *nameLayout = new QHBoxLayout;
    nameLayout->addWidget(new QLabel("Filter Name:", this));
    nameEdit = new QLineEdit(this);
    nameLayout->addWidget(nameEdit);
    mainLayout->addLayout(nameLayout);

        kernelTable = new QTableWidget(3, 3, this);
    kernelTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    kernelTable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        for (i32 i = 0; i < 3; i++) {
        for (i32 j = 0; j < 3; j++) {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText((i == 1 && j == 1) ? "1" : "0");
            kernelTable->setItem(i, j, item);
        }
    }
    mainLayout->addWidget(new QLabel("Kernel:"));
    mainLayout->addWidget(kernelTable);

    QHBoxLayout *paramLayout = new QHBoxLayout;
    paramLayout->addWidget(new QLabel("Divisor:", this));
    divisorEdit = new QLineEdit("1", this);
    paramLayout->addWidget(divisorEdit);
    paramLayout->addWidget(new QLabel("Offset:", this));
    offsetEdit = new QLineEdit("0", this);
    paramLayout->addWidget(offsetEdit);
    mainLayout->addLayout(paramLayout);

    saveButton = new QPushButton("Save", this);
    mainLayout->addWidget(saveButton);

    connect(saveButton, &QPushButton::clicked, this, &ConvolutionFilterEditor::onSaveClicked);
}

void ConvolutionFilterEditor::loadFilter(const std::string &name, const std::vector<std::vector<f32> > &kernel,
                                         f32 divisor, f32 offset) {
    nameEdit->setText(QString::fromStdString(name));
    for (i32 i = 0; i < 3; i++) {
        for (i32 j = 0; j < 3; j++) {
            kernelTable->item(i, j)->setText(QString::number(kernel[i][j]));
        }
    }
    nameEdit->setDisabled(true);
    divisorEdit->setText(QString::number(divisor));
    offsetEdit->setText(QString::number(offset));
}

void ConvolutionFilterEditor::onSaveClicked() {
    std::string filterName = nameEdit->text().toStdString();
    if (filterName.empty())
        return;
        std::vector<std::vector<f32> > kernel(3, std::vector<f32>(3, 0));
    for (i32 i = 0; i < 3; i++) {
        for (i32 j = 0; j < 3; j++) {
            kernel[i][j] = kernelTable->item(i, j)->text().toFloat();
        }
    }
    f32 divisor = divisorEdit->text().toFloat();
    f32 offset = offsetEdit->text().toFloat();

    auto filter = std::make_shared<ConvolutionFilter>(filterName, kernel, divisor, offset);
    emit filterSaved(filter);
    close();
}
