#ifndef MORPHOLOGICAL_FILTER_H
#define MORPHOLOGICAL_FILTER_H
#include "image_filter.h"


enum class MorphologicalOperation {
    Erosion,
    Dilation,
};

class MorphologicalFilter final : public ImageFilter {
public:
    explicit MorphologicalFilter(MorphologicalOperation op);

    [[nodiscard]] QImage apply(const QImage &input) const override;
    [[nodiscard]] std::string getName() const override {
        return operation == MorphologicalOperation::Erosion ? "Erosion" : "Dilation";
    }


private:
    MorphologicalOperation operation;
};


#endif
