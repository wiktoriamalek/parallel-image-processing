set(__QT_DEPLOY_TARGET_filters_FILE /Users/cieslam/CLionProjects/filters/cmake-build-debug/filters)
set(__QT_DEPLOY_TARGET_filters_TYPE EXECUTABLE)
