#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

#include <cstdint>

typedef int32_t  i32;
typedef uint32_t ui32;
typedef int64_t  i64;
typedef uint64_t ui64;
typedef float    f32;
typedef double   f64;

#endif