#include "functional_filter.h"

FunctionalFilter::FunctionalFilter(const std::string name, const std::vector<i32> &mapping)
    : mapping(mapping), name(name) {
}

QImage FunctionalFilter::apply(const QImage &input) const {
    QImage output = input;
    for (i32 y = 0; y < output.height(); y++) {
        for (i32 x = 0; x < output.width(); x++) {
            QColor color = output.pixelColor(x, y);
            const i32 newR = mapping[color.red()];
            const i32 newG = mapping[color.green()];
            const i32 newB = mapping[color.blue()];
            output.setPixelColor(x, y, QColor(newR, newG, newB));
        }
    }
    return output;
}

std::string FunctionalFilter::getName() const {
    return name;
}

QVector<QPoint> FunctionalFilter::getTenControlPoints() const {
    QVector<QPoint> points;
    const i32 steps = 9;
    for (i32 i = 0; i < 10; ++i) {
        i32 x = static_cast<i32>(std::round(i * 255.0 / steps));
        i32 y = 255 - mapping[x];
        points.push_back(QPoint(x, y));
    }
    return points;
}