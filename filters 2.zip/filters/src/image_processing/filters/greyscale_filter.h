#ifndef GRAYSCALE_FILTER_H
#define GRAYSCALE_FILTER_H

#include "image_filter.h"
#include <string>

class GreyscaleFilter : public ImageFilter {
public:
    ~GreyscaleFilter() override = default;
    [[nodiscard]] QImage apply(const QImage &input) const override;
    [[nodiscard]] std::string getName() const override;
};

#endif