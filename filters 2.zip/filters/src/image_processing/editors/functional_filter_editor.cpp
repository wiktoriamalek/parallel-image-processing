#include "functional_filter_editor.h"
#include "../filters/functional_filter.h"
#include <QPainter>
#include <QMouseEvent>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <algorithm>
#include <cmath>

FunctionalFilterEditor::FunctionalFilterEditor(QWidget *parent)
    : QWidget(parent), selectedPointIndex(-1)
{
    setWindowFlags(Qt::Window);
    setAttribute(Qt::WA_DeleteOnClose);

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(5);
    mainLayout->setContentsMargins(10, 10, 10, 10);

    auto *nameLayout = new QHBoxLayout;
    nameLayout->addWidget(new QLabel("Filter Name:", this));
    nameEdit = new QLineEdit(this);
    nameLayout->addWidget(nameEdit);
    mainLayout->addLayout(nameLayout);

    auto *drawingArea = new QWidget(this);
    drawingArea->setFixedSize(256, 256);
    drawingArea->setContentsMargins(10, 40, 10, 40);

    drawingArea->installEventFilter(this);
    mainLayout->addWidget(drawingArea, 0, Qt::AlignCenter);

    saveButton = new QPushButton("Save", this);
    mainLayout->addWidget(saveButton, 0, Qt::AlignCenter);

    connect(saveButton, &QPushButton::clicked, this, &FunctionalFilterEditor::onSaveClicked);

    controlPoints.clear();
    controlPoints.append(QPoint(0, 255));
    controlPoints.append(QPoint(255, 0));

    setLayout(mainLayout);
}

void FunctionalFilterEditor::loadFilter(const std::string &name, const QVector<QPoint> &points)
{
    nameEdit->setText(QString::fromStdString(name));
    nameEdit->setDisabled(true);
    controlPoints = points;
    update();
}

std::vector<i32> FunctionalFilterEditor::getMapping() const {
    std::vector<i32> mapping(256);
    for (i32 x = 0; x < 256; x++) {
        QPoint p1 = controlPoints.first();
        QPoint p2 = controlPoints.last();
        for (i32 i = 0; i < controlPoints.size() - 1; i++) {
            if (controlPoints[i].x() <= x && x <= controlPoints[i+1].x()) {
                p1 = controlPoints[i];
                p2 = controlPoints[i+1];
                break;
            }
        }
        f64 t = (x - p1.x()) / f64(p2.x() - p1.x());
        i32 y = p1.y() + t * (p2.y() - p1.y());
        mapping[x] = std::clamp(y, 0, 255);
    }
    return mapping;
}

void FunctionalFilterEditor::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter painter(this);
    painter.fillRect(QRect(0,0,256,256), Qt::white);
    painter.setPen(Qt::blue);
    for (i32 i = 0; i < controlPoints.size()-1; i++) {
        painter.drawLine(controlPoints[i], controlPoints[i+1]);
    }
    painter.setBrush(Qt::red);
    for (i32 i = 0; i < controlPoints.size(); i++) {
        painter.drawEllipse(controlPoints[i], 4, 4);
    }
}

void FunctionalFilterEditor::mousePressEvent(QMouseEvent *event) {
    QPoint pos = event->pos();
        if (pos.x() < 0 || pos.x() > 256 || pos.y() < 0 || pos.y() > 256)
        return;
        const i32 thresholdSq = 100;
    for (i32 i = 0; i < controlPoints.size(); i++) {
        if (distanceSq(pos, controlPoints[i]) < thresholdSq) {
            selectedPointIndex = i;
            return;
        }
    }
        if (pos.x() != 0 && pos.x() != 255) {
        auto it = std::upper_bound(controlPoints.begin(), controlPoints.end(), pos, [](const QPoint &a, const QPoint &b){
            return a.x() < b.x();
        });
        i32 newIdx = std::distance(controlPoints.begin(), it);
        controlPoints.insert(it, pos);
        selectedPointIndex = newIdx;
        update();
    }
}

void FunctionalFilterEditor::mouseMoveEvent(QMouseEvent *event) {
    if (selectedPointIndex < 0)
        return;
    QPoint pos = event->pos();
    pos.setX(std::clamp(pos.x(), 0, 255));
    pos.setY(std::clamp(pos.y(), 0, 255));
        if (selectedPointIndex == 0 || selectedPointIndex == controlPoints.size()-1)
        pos.setX(controlPoints[selectedPointIndex].x());
    else {
        i32 minX = controlPoints[selectedPointIndex - 1].x() + 1;
        i32 maxX = controlPoints[selectedPointIndex + 1].x() - 1;
        pos.setX(std::clamp(pos.x(), minX, maxX));
    }
    controlPoints[selectedPointIndex] = pos;
    update();
}

void FunctionalFilterEditor::mouseDoubleClickEvent(QMouseEvent *event) {
    QPoint pos = event->pos();
    const i32 thresholdSq = 100;
        for (i32 i = 1; i < controlPoints.size()-1; i++) {
        if (distanceSq(pos, controlPoints[i]) < thresholdSq) {
            controlPoints.remove(i);
            update();
            return;
        }
    }
}

void FunctionalFilterEditor::onSaveClicked() {
    std::string filterName = nameEdit->text().toStdString();
    if (filterName.empty())
        return;
    std::vector<i32> mapping = getMapping();
    // have to reverse because it's backwards and it flips on every save
    std::reverse(mapping.begin(), mapping.end());

    auto filter = std::make_shared<FunctionalFilter>(filterName, mapping);
    emit filterSaved(filter);

    close();
}

i32 FunctionalFilterEditor::distanceSq(const QPoint &p1, const QPoint &p2) const {
    i32 dx = p1.x() - p2.x();
    i32 dy = p1.y() - p2.y();
    return dx * dx + dy * dy;
}