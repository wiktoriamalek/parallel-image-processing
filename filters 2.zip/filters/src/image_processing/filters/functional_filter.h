#ifndef FUNCTIONALFILTER_H
#define FUNCTIONALFILTER_H

#include "image_filter.h"
#include <vector>
#include <QImage>

class FunctionalFilter final : public ImageFilter {
public:
    explicit FunctionalFilter(std::string name, const std::vector<i32>& mapping);

    [[nodiscard]] QImage apply(const QImage &input) const override;
    [[nodiscard]] std::string getName() const override;

    [[nodiscard]] QVector<QPoint> getTenControlPoints() const;

private:
    std::vector<i32> mapping;

    std::string name;
};

#endif
