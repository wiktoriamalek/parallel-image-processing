#include "morphological_filter.h"
#include <algorithm>

MorphologicalFilter::MorphologicalFilter(const MorphologicalOperation op) : operation(op) {
}


QImage MorphologicalFilter::apply(const QImage &input) const {
    QImage output(input.size(), input.format());

    constexpr i32 kw = 3;
    constexpr i32 kh = 3;
    constexpr i32 halfKW = 1;
    constexpr i32 halfKH = 1;

    const auto compareFunction = operation == MorphologicalOperation::Dilation
                               ? [](const i32 a, const i32 b) {
                                   if (a >= b) { return a; }
                                   return b;
                               }
                               : [](const i32 a, const i32 b) {
                                   if (a <= b) { return a; }
                                   return b;
                               };

    const i32 initialValue = operation == MorphologicalOperation::Dilation ? 0 : 255;

    for (i32 y = 0; y < input.height(); y++) {
        for (i32 x = 0; x < input.width(); x++) {
            i32 finalR = initialValue, finalG = initialValue, finalB = initialValue;
            for (i32 j = 0; j < kh; j++) {
                for (i32 i = 0; i < kw; i++) {
                    i32 curX = x + i - halfKW;
                    i32 curY = y + j - halfKH;
                    curX = std::clamp(curX, 0, input.width() - 1);
                    curY = std::clamp(curY, 0, input.height() - 1);
                    QColor pixel = input.pixelColor(curX, curY);

                    finalR = compareFunction(pixel.red(), finalR);
                    finalG = compareFunction(pixel.green(), finalR);
                    finalB = compareFunction(pixel.blue(), finalR);
                }
            }
            output.setPixelColor(x, y, QColor(finalR, finalG, finalB));
        }
    }
    return output;
}
