#ifndef CONVOLUTION_FILTER_EDITOR_H
#define CONVOLUTION_FILTER_EDITOR_H

#include <QWidget>
#include <vector>
#include <memory>
#include <string>

class QTableWidget;
class QLineEdit;
class QPushButton;
class ImageFilter;

class ConvolutionFilterEditor final : public QWidget {
    Q_OBJECT

public:
    explicit ConvolutionFilterEditor(QWidget *parent = nullptr);

    void loadFilter(const std::string &name, const std::vector<std::vector<f32> > &kernel, f32 divisor,
                    f32 offset);

signals:
    void filterSaved(std::shared_ptr<ImageFilter> filter);

private slots:
    void onSaveClicked();

private:
    QLineEdit *nameEdit;
    QTableWidget *kernelTable;
    QLineEdit *divisorEdit;
    QLineEdit *offsetEdit;
    QPushButton *saveButton;
};

#endif
