#include "greyscale_filter.h"
#include <QImage>
#include <QColor>

QImage GreyscaleFilter::apply(const QImage &input) const {
    QImage output = input.convertToFormat(QImage::Format_RGB32);
    int width = output.width();
    int height = output.height();
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QColor color = output.pixelColor(x, y);
            int gray = static_cast<int>(0.299 * color.red() +
                                        0.587 * color.green() +
                                        0.114 * color.blue());
            QColor grayColor(gray, gray, gray);
            output.setPixelColor(x, y, grayColor);
        }
    }
    return output;
}

std::string GreyscaleFilter::getName() const {
    return "Greyscale";
}