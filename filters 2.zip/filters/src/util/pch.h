#ifndef PCH_H
#define PCH_H

/**
 * Congregate file for all headers to be precompiled.
*/

#include "headers/common_types.h"

#endif
