#ifndef IMAGEFILTER_H
#define IMAGEFILTER_H

#include <QImage>

class ImageFilter {
public:
    virtual ~ImageFilter() = default;
    [[nodiscard]] virtual QImage apply(const QImage &input) const = 0;
    [[nodiscard]] virtual std::string getName() const = 0;
};

#endif