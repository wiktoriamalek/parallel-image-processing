#ifndef MEDIAN_CUT_QUANTIZATION_FILTER_H
#define MEDIAN_CUT_QUANTIZATION_FILTER_H

#include "image_filter.h"
#include <string>

class MedianCutQuantizationFilter : public ImageFilter {
    std::string name;

public:
    explicit MedianCutQuantizationFilter(int desiredColors, std::string filterName = "Median Cut Quantization");

    [[nodiscard]] QImage apply(const QImage &input) const override;

    [[nodiscard]] std::string getName() const override;

    void setDesiredColors(int desiredColors);

    [[nodiscard]] int getDesiredColors() const;

private:
    int desiredColors;
};

#endif
