#include "median_cut_quantization_filter.h"
#include <QImage>
#include <vector>
#include <limits>
#include <algorithm>
#include <numeric>

struct ColorBox {
    std::vector<QColor> colors;
    int rmin, rmax, gmin, gmax, bmin, bmax;
};

static void computeBounds(ColorBox &box) {
    if (box.colors.empty()) return;
    box.rmin = box.gmin = box.bmin = 255;
    box.rmax = box.gmax = box.bmax = 0;
    for (const QColor &color: box.colors) {
        int r = color.red(), g = color.green(), b = color.blue();
        box.rmin = std::min(box.rmin, r);
        box.rmax = std::max(box.rmax, r);
        box.gmin = std::min(box.gmin, g);
        box.gmax = std::max(box.gmax, g);
        box.bmin = std::min(box.bmin, b);
        box.bmax = std::max(box.bmax, b);
    }
}

static int getLongestColorChannel(const ColorBox &box) {
    int rRange = box.rmax - box.rmin;
    int gRange = box.gmax - box.gmin;
    int bRange = box.bmax - box.bmin;
    if (rRange >= gRange && rRange >= bRange)
        return 0;
    else if (gRange >= rRange && gRange >= bRange)
        return 1;
    else
        return 2;
}

static std::vector<ColorBox> medianCut(std::vector<ColorBox> boxes, int targetBoxes) {
    while (boxes.size() < static_cast<size_t>(targetBoxes)) {
        auto it = std::max_element(boxes.begin(), boxes.end(), [](const ColorBox &a, const ColorBox &b) {
            return a.colors.size() < b.colors.size();
        });
        if (it == boxes.end() || it->colors.size() < 2)
            break;
        ColorBox box = *it;
        boxes.erase(it);
        computeBounds(box);
        int channel = getLongestColorChannel(box);
        std::sort(box.colors.begin(), box.colors.end(), [channel](const QColor &a, const QColor &b) {
            if (channel == 0)
                return a.red() < b.red();
            else if (channel == 1)
                return a.green() < b.green();
            else
                return a.blue() < b.blue();
        });
        size_t medianIndex = box.colors.size() / 2;
        ColorBox box1, box2;
        box1.colors.assign(box.colors.begin(), box.colors.begin() + medianIndex);
        box2.colors.assign(box.colors.begin() + medianIndex, box.colors.end());
        computeBounds(box1);
        computeBounds(box2);
        boxes.push_back(box1);
        boxes.push_back(box2);
    }
    return boxes;
}

static QColor averageColor(const ColorBox &box) {
    if (box.colors.empty())
        return QColor(0, 0, 0);
    qint64 sumR = 0, sumG = 0, sumB = 0;
    for (const QColor &color: box.colors) {
        sumR += color.red();
        sumG += color.green();
        sumB += color.blue();
    }
    int count = box.colors.size();
    return QColor(sumR / count, sumG / count, sumB / count);
}

QImage MedianCutQuantizationFilter::apply(const QImage &input) const {
    QImage image = input.convertToFormat(QImage::Format_RGB32);
    int width = image.width();
    int height = image.height();

    // Collect all pixel colors.
    std::vector<QColor> allColors;
    allColors.reserve(width * height);
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            allColors.push_back(image.pixelColor(x, y));
        }
    }

    ColorBox initialBox;
    initialBox.colors = allColors;
    computeBounds(initialBox);
    std::vector<ColorBox> boxes;
    boxes.push_back(initialBox);

    boxes = medianCut(boxes, desiredColors);

    std::vector<QColor> palette;
    for (const ColorBox &box: boxes) {
        palette.push_back(averageColor(box));
    }

    QImage output(width, height, QImage::Format_RGB32);
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            QColor orig = image.pixelColor(x, y);
            int bestIndex = 0;
            int bestDist = std::numeric_limits<int>::max();
            for (size_t i = 0; i < palette.size(); i++) {
                int dr = orig.red() - palette[i].red();
                int dg = orig.green() - palette[i].green();
                int db = orig.blue() - palette[i].blue();
                int dist = dr * dr + dg * dg + db * db;
                if (dist < bestDist) {
                    bestDist = dist;
                    bestIndex = i;
                }
            }
            output.setPixelColor(x, y, palette[bestIndex]);
        }
    }
    return output;
}


void MedianCutQuantizationFilter::setDesiredColors(int desiredColors) {
    this->desiredColors = desiredColors;
}

int MedianCutQuantizationFilter::getDesiredColors() const {
    return desiredColors;
}

std::string MedianCutQuantizationFilter::getName() const {
    return name;
}

MedianCutQuantizationFilter::MedianCutQuantizationFilter(int desiredColors, std::string name)
    : desiredColors(desiredColors), name(name) {
}
