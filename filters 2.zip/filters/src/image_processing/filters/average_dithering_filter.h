#ifndef AVERAGE_DITHERING_FILTER_H
#define AVERAGE_DITHERING_FILTER_H

#include "image_filter.h"
#include <string>

class AverageDitheringFilter : public ImageFilter {
    int greyLevels;
public:
    AverageDitheringFilter(int greyLevels = 5);
    [[nodiscard]] QImage apply(const QImage &input) const override;
    [[nodiscard]] std::string getName() const override;
};


#endif
