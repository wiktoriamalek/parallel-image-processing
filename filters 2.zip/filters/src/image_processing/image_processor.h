#ifndef IMAGEPROCESSOR_H
#define IMAGEPROCESSOR_H

#include <vector>
#include <QImage>

#include "filters/image_filter.h"

class ImageProcessor {
public:
    void setImage(const QImage &img);

    [[nodiscard]] const QImage &getImage() const;
    [[nodiscard]] QImage applyFilter(const ImageFilter *filter) const;

private:
    QImage image;
};

#endif
