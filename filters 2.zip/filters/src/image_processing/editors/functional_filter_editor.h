#ifndef FUNCTIONAL_FILTER_EDITOR_H
#define FUNCTIONAL_FILTER_EDITOR_H

#include <QWidget>
#include <QVector>
#include <vector>

class ImageFilter;
class QLineEdit;
class QPushButton;

class FunctionalFilterEditor final : public QWidget {
    Q_OBJECT

public:
    explicit FunctionalFilterEditor(QWidget *parent = nullptr);

    void loadFilter(const std::string &name, const QVector<QPoint> &points);

    [[nodiscard]] std::vector<i32> getMapping() const;

signals:
    void filterSaved(std::shared_ptr<ImageFilter> filter);

protected:
    void paintEvent(QPaintEvent *event) override;

    void mousePressEvent(QMouseEvent *event) override;

    void mouseMoveEvent(QMouseEvent *event) override;

    void mouseDoubleClickEvent(QMouseEvent *event) override;

private slots:
    void onSaveClicked();

private:
    QLineEdit *nameEdit;
    QPushButton *saveButton;
    QVector<QPoint> controlPoints;
    i32 selectedPointIndex;

    [[nodiscard]] i32 distanceSq(const QPoint &p1, const QPoint &p2) const;
};

#endif
